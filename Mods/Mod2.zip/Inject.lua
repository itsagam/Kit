inject(typeof(CS.Demos.Modding.Demo), "InjectedReplace",  
function ()
	Kit.SceneDirector.LoadScene("Menu")
end)

inject(typeof(CS.Demos.Modding.Demo), "InjectedExtend",
function (demo)
	demo:InjectedExtend()
	print(self.Name .. " Code")
	demo:InjectedExtend()
end)